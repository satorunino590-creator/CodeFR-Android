package com.codefr.editor

import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var editor: EditText
    private lateinit var languageSpinner: Spinner
    private val languages = arrayOf("Texte","Kotlin","Java","Python","JavaScript","HTML")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editor = findViewById(R.id.editor)
        languageSpinner = findViewById(R.id.languageSpinner)
        languageSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages)

        findViewById<Button>(R.id.newButton).setOnClickListener { editor.setText("") }
        findViewById<Button>(R.id.clearButton).setOnClickListener { editor.setText("") }
        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, editor.text.toString())
            }
            startActivity(Intent.createChooser(i, "Partager le code"))
        }
        findViewById<Button>(R.id.runButton).setOnClickListener { preview() }
    }

    private fun preview() {
        val language = languageSpinner.selectedItem.toString()
        if (language != "HTML") {
            Toast.makeText(this, "Le mode $language est prêt pour l'édition. L'aperçu intégré concerne HTML.", Toast.LENGTH_LONG).show()
            return
        }
        val view = WebView(this).apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            loadDataWithBaseURL(null, editor.text.toString(), "text/html", "UTF-8", null)
        }
        AlertDialog.Builder(this).setTitle("Aperçu HTML").setView(view).setPositiveButton("Fermer", null).show()
    }
}
