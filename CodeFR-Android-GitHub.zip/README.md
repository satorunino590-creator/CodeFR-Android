# Code FR — Projet Android

Éditeur de code Android en français, pensé pour une utilisation sur téléphone.

## Fonctions
- Interface française
- Éditeur de code
- Nouveau / Effacer / Partager
- Sélection Kotlin, Java, Python, JavaScript, HTML
- Aperçu HTML intégré
- Thème sombre
- Android 6.0+ (API 23+)

## Compilation GitHub
Le dossier `.github/workflows/build-apk.yml` compile automatiquement l'APK debug.
Ouvre **Actions**, puis **Construire l'APK Android**. À la fin, télécharge l'artefact **CodeFR-debug-apk**.
